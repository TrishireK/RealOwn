import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { searchLeadsSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get dashboard statistics
  app.get("/api/stats", async (req, res) => {
    try {
      const stats = await storage.getDashboardStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch dashboard stats" });
    }
  });

  // Get location statistics
  app.get("/api/stats/locations", async (req, res) => {
    try {
      const locationStats = await storage.getLocationStats();
      res.json(locationStats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch location stats" });
    }
  });

  // Get type statistics
  app.get("/api/stats/types", async (req, res) => {
    try {
      const typeStats = await storage.getTypeStats();
      res.json(typeStats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch type stats" });
    }
  });

  // Search leads with filters and pagination
  app.get("/api/leads", async (req, res) => {
    try {
      const searchParams = {
        location: req.query.location as string,
        requirementType: req.query.requirementType as string,
        budgetRange: req.query.budgetRange as string,
        dateRange: req.query.dateRange as string,
        search: req.query.search as string,
        page: parseInt(req.query.page as string) || 1,
        limit: parseInt(req.query.limit as string) || 10,
      };

      const validation = searchLeadsSchema.safeParse(searchParams);
      if (!validation.success) {
        return res.status(400).json({ error: "Invalid search parameters" });
      }

      const result = await storage.getLeads(validation.data);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch leads" });
    }
  });

  // Get lead by ID
  app.get("/api/leads/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid lead ID" });
      }

      const lead = await storage.getLeadById(id);
      if (!lead) {
        return res.status(404).json({ error: "Lead not found" });
      }

      res.json(lead);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch lead" });
    }
  });

  // Export leads as CSV
  app.get("/api/leads/export", async (req, res) => {
    try {
      const searchParams = {
        location: req.query.location as string,
        requirementType: req.query.requirementType as string,
        budgetRange: req.query.budgetRange as string,
        dateRange: req.query.dateRange as string,
        search: req.query.search as string,
        page: 1,
        limit: 10000, // Export all matching leads
      };

      const validation = searchLeadsSchema.safeParse(searchParams);
      if (!validation.success) {
        return res.status(400).json({ error: "Invalid search parameters" });
      }

      const result = await storage.getLeads(validation.data);
      
      // Convert to CSV
      const csvHeaders = ["Name", "Phone", "Email", "Requirement", "Location", "Area", "Budget", "Created Date"];
      const csvRows = result.leads.map(lead => [
        lead.name,
        lead.phone,
        lead.email || "",
        lead.requirementType,
        lead.location,
        lead.area,
        lead.budget || "",
        lead.createdAt?.toISOString().split('T')[0] || "",
      ]);

      const csvContent = [csvHeaders, ...csvRows]
        .map(row => row.map(field => `"${field}"`).join(","))
        .join("\n");

      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", "attachment; filename=leads-export.csv");
      res.send(csvContent);
    } catch (error) {
      res.status(500).json({ error: "Failed to export leads" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
