import { leads, users, type User, type InsertUser, type Lead, type InsertLead, type SearchLeadsParams } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Lead management
  getLeads(params: SearchLeadsParams): Promise<{ leads: Lead[], total: number }>;
  createLead(lead: InsertLead): Promise<Lead>;
  updateLead(id: number, lead: Partial<InsertLead>): Promise<Lead | undefined>;
  deleteLead(id: number): Promise<boolean>;
  getLeadById(id: number): Promise<Lead | undefined>;
  
  // Statistics
  getDashboardStats(): Promise<{
    todayLeads: number;
    propertySeeker: number;
    loanSeeker: number;
    activeLocations: number;
  }>;
  
  getLocationStats(): Promise<Array<{ location: string; count: number }>>;
  getTypeStats(): Promise<Array<{ type: string; count: number }>>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private leads: Map<number, Lead>;
  private currentUserId: number;
  private currentLeadId: number;

  constructor() {
    this.users = new Map();
    this.leads = new Map();
    this.currentUserId = 1;
    this.currentLeadId = 1;
    
    // Initialize with some sample data to simulate AI collection
    this.initializeSampleData();
  }

  private initializeSampleData() {
    const sampleLeads: InsertLead[] = [
      {
        name: "Rajesh Agarwal",
        phone: "+91 9876543210",
        email: "rajesh.a@gmail.com",
        requirementType: "flat",
        location: "Bandra West, Mumbai",
        area: "Maharashtra",
        budget: "₹75 - 90 Lakhs",
        budgetMin: 7500000,
        budgetMax: 9000000,
        details: "Looking for 2 BHK flat",
        isActive: true,
      },
      {
        name: "Priya Sharma",
        phone: "+91 8765432109",
        email: "priya.sharma@yahoo.com",
        requirementType: "home_loan",
        location: "Sector 45, Gurgaon",
        area: "Haryana",
        budget: "₹45 Lakhs",
        budgetMin: 4500000,
        budgetMax: 4500000,
        details: "Home loan for first property",
        isActive: true,
      },
      {
        name: "Amit Kumar",
        phone: "+91 7654321098",
        email: "amit.k@hotmail.com",
        requirementType: "plot",
        location: "Electronic City, Bangalore",
        area: "Karnataka",
        budget: "₹25 - 35 Lakhs",
        budgetMin: 2500000,
        budgetMax: 3500000,
        details: "Residential plot for villa construction",
        isActive: true,
      },
      {
        name: "Sunita Gupta",
        phone: "+91 6543210987",
        email: "sunita.g@gmail.com",
        requirementType: "business_loan",
        location: "Connaught Place, Delhi",
        area: "Delhi NCR",
        budget: "₹15 Lakhs",
        budgetMin: 1500000,
        budgetMax: 1500000,
        details: "Business expansion loan",
        isActive: true,
      },
      {
        name: "Manoj Reddy",
        phone: "+91 5432109876",
        email: "manoj.r@outlook.com",
        requirementType: "flat",
        location: "Hitech City, Hyderabad",
        area: "Telangana",
        budget: "₹1.2 - 1.5 Crores",
        budgetMin: 12000000,
        budgetMax: 15000000,
        details: "3 BHK villa",
        isActive: true,
      },
    ];

    sampleLeads.forEach(lead => {
      this.createLead(lead);
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getLeads(params: SearchLeadsParams): Promise<{ leads: Lead[], total: number }> {
    let filteredLeads = Array.from(this.leads.values()).filter(lead => lead.isActive);

    // Apply filters
    if (params.location && params.location !== "all" && params.location !== "All Locations") {
      filteredLeads = filteredLeads.filter(lead => 
        lead.location.toLowerCase().includes(params.location!.toLowerCase()) ||
        lead.area.toLowerCase().includes(params.location!.toLowerCase())
      );
    }

    if (params.requirementType && params.requirementType !== "all" && params.requirementType !== "All Types") {
      const typeMap: Record<string, string> = {
        "Flat/Apartment": "flat",
        "Plot/Land": "plot",
        "Home Loan": "home_loan",
        "Personal Loan": "personal_loan",
        "Business Loan": "business_loan",
      };
      const mappedType = typeMap[params.requirementType] || params.requirementType;
      filteredLeads = filteredLeads.filter(lead => lead.requirementType === mappedType);
    }

    if (params.budgetRange && params.budgetRange !== "all" && params.budgetRange !== "Any Budget") {
      const budgetRanges: Record<string, { min: number, max: number }> = {
        "Under ₹25 Lakhs": { min: 0, max: 2500000 },
        "₹25L - ₹50L": { min: 2500000, max: 5000000 },
        "₹50L - ₹1 Crore": { min: 5000000, max: 10000000 },
        "Above ₹1 Crore": { min: 10000000, max: Infinity },
      };
      const range = budgetRanges[params.budgetRange];
      if (range) {
        filteredLeads = filteredLeads.filter(lead => 
          (lead.budgetMin && lead.budgetMin >= range.min && lead.budgetMin <= range.max) ||
          (lead.budgetMax && lead.budgetMax >= range.min && lead.budgetMax <= range.max)
        );
      }
    }

    if (params.search) {
      const searchTerm = params.search.toLowerCase();
      filteredLeads = filteredLeads.filter(lead =>
        lead.name.toLowerCase().includes(searchTerm) ||
        lead.phone.includes(searchTerm) ||
        lead.location.toLowerCase().includes(searchTerm) ||
        (lead.email && lead.email.toLowerCase().includes(searchTerm))
      );
    }

    // Apply date filter
    if (params.dateRange && params.dateRange !== "all" && params.dateRange !== "All Time") {
      const now = new Date();
      let filterDate = new Date();
      
      switch (params.dateRange) {
        case "Today":
          filterDate.setHours(0, 0, 0, 0);
          break;
        case "Last 7 days":
          filterDate.setDate(now.getDate() - 7);
          break;
        case "Last 30 days":
          filterDate.setDate(now.getDate() - 30);
          break;
      }
      
      filteredLeads = filteredLeads.filter(lead => 
        lead.createdAt && new Date(lead.createdAt) >= filterDate
      );
    }

    // Sort by most recent
    filteredLeads.sort((a, b) => 
      (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0)
    );

    const total = filteredLeads.length;
    const offset = (params.page - 1) * params.limit;
    const paginatedLeads = filteredLeads.slice(offset, offset + params.limit);

    return { leads: paginatedLeads, total };
  }

  async createLead(lead: InsertLead): Promise<Lead> {
    const id = this.currentLeadId++;
    const now = new Date();
    const newLead: Lead = { 
      ...lead, 
      id, 
      createdAt: now,
      updatedAt: now,
    };
    this.leads.set(id, newLead);
    return newLead;
  }

  async updateLead(id: number, leadUpdate: Partial<InsertLead>): Promise<Lead | undefined> {
    const existingLead = this.leads.get(id);
    if (!existingLead) return undefined;

    const updatedLead: Lead = {
      ...existingLead,
      ...leadUpdate,
      updatedAt: new Date(),
    };
    this.leads.set(id, updatedLead);
    return updatedLead;
  }

  async deleteLead(id: number): Promise<boolean> {
    return this.leads.delete(id);
  }

  async getLeadById(id: number): Promise<Lead | undefined> {
    return this.leads.get(id);
  }

  async getDashboardStats(): Promise<{
    todayLeads: number;
    propertySeeker: number;
    loanSeeker: number;
    activeLocations: number;
  }> {
    const allLeads = Array.from(this.leads.values()).filter(lead => lead.isActive);
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const todayLeads = allLeads.filter(lead => 
      lead.createdAt && new Date(lead.createdAt) >= today
    ).length;

    const propertySeeker = allLeads.filter(lead => 
      lead.requirementType === 'flat' || lead.requirementType === 'plot'
    ).length;

    const loanSeeker = allLeads.filter(lead => 
      lead.requirementType === 'home_loan' || 
      lead.requirementType === 'business_loan' || 
      lead.requirementType === 'personal_loan'
    ).length;

    const uniqueLocations = new Set(allLeads.map(lead => lead.area));
    const activeLocations = uniqueLocations.size;

    return {
      todayLeads,
      propertySeeker,
      loanSeeker,
      activeLocations,
    };
  }

  async getLocationStats(): Promise<Array<{ location: string; count: number }>> {
    const allLeads = Array.from(this.leads.values()).filter(lead => lead.isActive);
    const locationCounts = new Map<string, number>();

    allLeads.forEach(lead => {
      const count = locationCounts.get(lead.area) || 0;
      locationCounts.set(lead.area, count + 1);
    });

    return Array.from(locationCounts.entries())
      .map(([location, count]) => ({ location, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
  }

  async getTypeStats(): Promise<Array<{ type: string; count: number }>> {
    const allLeads = Array.from(this.leads.values()).filter(lead => lead.isActive);
    const typeCounts = new Map<string, number>();

    const typeDisplayNames: Record<string, string> = {
      flat: "Flat/Apartment",
      plot: "Residential Plot",
      home_loan: "Home Loan",
      business_loan: "Business Loan",
      personal_loan: "Personal Loan",
    };

    allLeads.forEach(lead => {
      const displayName = typeDisplayNames[lead.requirementType] || lead.requirementType;
      const count = typeCounts.get(displayName) || 0;
      typeCounts.set(displayName, count + 1);
    });

    return Array.from(typeCounts.entries())
      .map(([type, count]) => ({ type, count }))
      .sort((a, b) => b.count - a.count);
  }
}

export const storage = new MemStorage();
