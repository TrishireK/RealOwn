import { AppHeader } from "@/components/app-header";
import { DashboardStats } from "@/components/dashboard-stats";
import { SearchInterface } from "@/components/search-interface";
import { LeadsTable } from "@/components/leads-table";
import { AnalyticsSection } from "@/components/analytics-section";
import { AIStatus } from "@/components/ai-status";
import { useState } from "react";
import type { SearchLeadsParams } from "@shared/schema";

export default function Dashboard() {
  const [searchParams, setSearchParams] = useState<Partial<SearchLeadsParams>>({
    page: 1,
    limit: 10,
  });

  const handleSearch = (params: Partial<SearchLeadsParams>) => {
    setSearchParams({ ...params, page: 1 });
  };

  const handlePageChange = (page: number) => {
    setSearchParams(prev => ({ ...prev, page }));
  };

  return (
    <div className="min-h-screen bg-background">
      <AppHeader />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <DashboardStats />
        
        <SearchInterface onSearch={handleSearch} />
        
        <LeadsTable 
          searchParams={searchParams} 
          onPageChange={handlePageChange}
        />
        
        <AnalyticsSection />
        
        <AIStatus />
      </main>

      {/* Mobile Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 md:hidden z-50">
        <div className="grid grid-cols-4 gap-1">
          <button className="flex flex-col items-center py-2 text-primary">
            <i className="fas fa-home text-lg"></i>
            <span className="text-xs mt-1">Dashboard</span>
          </button>
          <button className="flex flex-col items-center py-2 text-gray-600">
            <i className="fas fa-search text-lg"></i>
            <span className="text-xs mt-1">Search</span>
          </button>
          <button className="flex flex-col items-center py-2 text-gray-600">
            <i className="fas fa-chart-bar text-lg"></i>
            <span className="text-xs mt-1">Analytics</span>
          </button>
          <button className="flex flex-col items-center py-2 text-gray-600">
            <i className="fas fa-download text-lg"></i>
            <span className="text-xs mt-1">Export</span>
          </button>
        </div>
      </div>
    </div>
  );
}
