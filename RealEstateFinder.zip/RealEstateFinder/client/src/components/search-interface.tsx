import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";
import type { SearchLeadsParams } from "@shared/schema";

interface SearchInterfaceProps {
  onSearch: (params: Partial<SearchLeadsParams>) => void;
}

export function SearchInterface({ onSearch }: SearchInterfaceProps) {
  const [filters, setFilters] = useState({
    location: "all",
    requirementType: "all",
    budgetRange: "all",
    dateRange: "all",
    search: "",
  });
  
  const [isSearching, setIsSearching] = useState(false);

  const handleSearch = async () => {
    setIsSearching(true);
    // Simulate search delay for better UX
    await new Promise(resolve => setTimeout(resolve, 500));
    onSearch(filters);
    setIsSearching(false);
  };

  const handleExport = async () => {
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value) params.append(key, value);
    });
    
    window.open(`/api/leads/export?${params.toString()}`, '_blank');
  };

  return (
    <section className="mb-8">
      <Card className="border border-gray-100">
        <CardHeader className="border-b border-gray-100">
          <CardTitle className="text-lg font-semibold text-secondary flex items-center">
            <i className="fas fa-search mr-2 text-primary"></i>
            Advanced Lead Search
          </CardTitle>
          <p className="text-sm text-gray-600">
            Find property and loan seekers based on location and requirements
          </p>
        </CardHeader>
        
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Location</Label>
              <div className="relative">
                <i className="fas fa-map-marker-alt absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                <Select value={filters.location} onValueChange={(value) => setFilters(prev => ({ ...prev, location: value }))}>
                  <SelectTrigger className="pl-10">
                    <SelectValue placeholder="All Locations" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Locations</SelectItem>
                    <SelectItem value="Mumbai, Maharashtra">Mumbai, Maharashtra</SelectItem>
                    <SelectItem value="Delhi, NCR">Delhi, NCR</SelectItem>
                    <SelectItem value="Bangalore, Karnataka">Bangalore, Karnataka</SelectItem>
                    <SelectItem value="Chennai, Tamil Nadu">Chennai, Tamil Nadu</SelectItem>
                    <SelectItem value="Hyderabad, Telangana">Hyderabad, Telangana</SelectItem>
                    <SelectItem value="Pune, Maharashtra">Pune, Maharashtra</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Requirement Type</Label>
              <div className="relative">
                <i className="fas fa-filter absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                <Select value={filters.requirementType} onValueChange={(value) => setFilters(prev => ({ ...prev, requirementType: value }))}>
                  <SelectTrigger className="pl-10">
                    <SelectValue placeholder="All Types" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="Flat/Apartment">Flat/Apartment</SelectItem>
                    <SelectItem value="Plot/Land">Plot/Land</SelectItem>
                    <SelectItem value="Home Loan">Home Loan</SelectItem>
                    <SelectItem value="Personal Loan">Personal Loan</SelectItem>
                    <SelectItem value="Business Loan">Business Loan</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Budget Range</Label>
              <div className="relative">
                <i className="fas fa-rupee-sign absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                <Select value={filters.budgetRange} onValueChange={(value) => setFilters(prev => ({ ...prev, budgetRange: value }))}>
                  <SelectTrigger className="pl-10">
                    <SelectValue placeholder="Any Budget" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Any Budget</SelectItem>
                    <SelectItem value="Under ₹25 Lakhs">Under ₹25 Lakhs</SelectItem>
                    <SelectItem value="₹25L - ₹50L">₹25L - ₹50L</SelectItem>
                    <SelectItem value="₹50L - ₹1 Crore">₹50L - ₹1 Crore</SelectItem>
                    <SelectItem value="Above ₹1 Crore">Above ₹1 Crore</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Date Added</Label>
              <div className="relative">
                <i className="fas fa-calendar absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                <Select value={filters.dateRange} onValueChange={(value) => setFilters(prev => ({ ...prev, dateRange: value }))}>
                  <SelectTrigger className="pl-10">
                    <SelectValue placeholder="All Time" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Time</SelectItem>
                    <SelectItem value="Today">Today</SelectItem>
                    <SelectItem value="Last 7 days">Last 7 days</SelectItem>
                    <SelectItem value="Last 30 days">Last 30 days</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                <Input
                  type="text"
                  placeholder="Search by name, phone, or area..."
                  className="pl-10"
                  value={filters.search}
                  onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
                />
              </div>
            </div>
            <Button 
              onClick={handleSearch}
              disabled={isSearching}
              className="bg-primary hover:bg-blue-700 text-white"
            >
              {isSearching ? (
                <>
                  <i className="fas fa-spinner fa-spin mr-2"></i>
                  Searching...
                </>
              ) : (
                <>
                  <i className="fas fa-search mr-2"></i>
                  Search Leads
                </>
              )}
            </Button>
            <Button 
              variant="outline"
              onClick={handleExport}
              className="bg-gray-100 hover:bg-gray-200 text-gray-700"
            >
              <i className="fas fa-download mr-2"></i>
              Export
            </Button>
          </div>
        </CardContent>
      </Card>
    </section>
  );
}
