import { Button } from "@/components/ui/button";
import { Avatar, AvatarContent, AvatarFallback } from "@/components/ui/avatar";

export function AppHeader() {
  return (
    <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <i className="fas fa-home text-primary text-2xl"></i>
              <h1 className="text-xl font-bold text-secondary">PropertyConnect</h1>
            </div>
            <nav className="hidden md:flex space-x-6">
              <a href="#dashboard" className="text-primary font-medium border-b-2 border-primary pb-1">
                Dashboard
              </a>
              <a href="#search" className="text-gray-600 hover:text-primary transition-colors">
                Search Leads
              </a>
              <a href="#analytics" className="text-gray-600 hover:text-primary transition-colors">
                Analytics
              </a>
              <a href="#exports" className="text-gray-600 hover:text-primary transition-colors">
                Exports
              </a>
            </nav>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="ghost" className="relative p-2 text-gray-600 hover:text-primary">
              <i className="fas fa-bell text-lg"></i>
              <span className="absolute -top-1 -right-1 h-4 w-4 bg-warning rounded-full text-xs text-white flex items-center justify-center">
                3
              </span>
            </Button>
            <div className="flex items-center space-x-2">
              <Avatar className="h-8 w-8">
                <AvatarFallback className="bg-primary text-white text-sm">
                  AU
                </AvatarFallback>
              </Avatar>
              <span className="hidden md:block text-sm font-medium">Admin User</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
