import { Card, CardContent } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";

interface DashboardStats {
  todayLeads: number;
  propertySeeker: number;
  loanSeeker: number;
  activeLocations: number;
}

export function DashboardStats() {
  const { data: stats, isLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/stats"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  if (isLoading) {
    return (
      <section className="mb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-20 bg-gray-200 rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    );
  }

  if (!stats) {
    return (
      <section className="mb-8">
        <Card>
          <CardContent className="p-6 text-center text-gray-500">
            Failed to load dashboard statistics. Please try again.
          </CardContent>
        </Card>
      </section>
    );
  }

  return (
    <section className="mb-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="border border-gray-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Leads Today</p>
                <p className="text-3xl font-bold text-secondary">{stats.todayLeads}</p>
                <p className="text-sm text-success">
                  <i className="fas fa-arrow-up"></i> Updated daily
                </p>
              </div>
              <div className="h-12 w-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <i className="fas fa-users text-primary text-xl"></i>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border border-gray-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Property Seekers</p>
                <p className="text-3xl font-bold text-secondary">{stats.propertySeeker}</p>
                <p className="text-sm text-success">
                  <i className="fas fa-arrow-up"></i> Flats & Plots
                </p>
              </div>
              <div className="h-12 w-12 bg-accent/10 rounded-lg flex items-center justify-center">
                <i className="fas fa-building text-accent text-xl"></i>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border border-gray-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Loan Seekers</p>
                <p className="text-3xl font-bold text-secondary">{stats.loanSeeker}</p>
                <p className="text-sm text-success">
                  <i className="fas fa-arrow-up"></i> All loan types
                </p>
              </div>
              <div className="h-12 w-12 bg-success/10 rounded-lg flex items-center justify-center">
                <i className="fas fa-credit-card text-success text-xl"></i>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border border-gray-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Locations</p>
                <p className="text-3xl font-bold text-secondary">{stats.activeLocations}</p>
                <p className="text-sm text-gray-500">Across India</p>
              </div>
              <div className="h-12 w-12 bg-warning/10 rounded-lg flex items-center justify-center">
                <i className="fas fa-map-marker-alt text-warning text-xl"></i>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
