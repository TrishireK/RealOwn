import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useState, useEffect } from "react";

export function AIStatus() {
  const [lastUpdate, setLastUpdate] = useState<string>("30 minutes ago");
  const [processLogs, setProcessLogs] = useState([
    { time: "11:45 AM", status: "success", message: "Processed 23 leads from Mumbai portals" },
    { time: "11:30 AM", status: "success", message: "Validated 15 contact numbers in Delhi" },
    { time: "11:15 AM", status: "warning", message: "Rate limited on source XYZ - retrying" },
    { time: "11:00 AM", status: "success", message: "Found 31 new leads in Bangalore" },
    { time: "10:45 AM", status: "success", message: "Updated location mapping for Hyderabad" },
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate real-time updates
      const now = new Date();
      const randomMinutes = Math.floor(Math.random() * 60);
      if (randomMinutes < 5) {
        setLastUpdate("Just now");
        // Add a new log entry occasionally
        if (Math.random() < 0.3) {
          const newLog = {
            time: now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            status: "success" as const,
            message: `Processed ${Math.floor(Math.random() * 30 + 10)} leads from various sources`,
          };
          setProcessLogs(prev => [newLog, ...prev.slice(0, 4)]);
        }
      } else {
        setLastUpdate(`${randomMinutes} minutes ago`);
      }
    }, 30000); // Update every 30 seconds

    return () => clearInterval(interval);
  }, []);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "success":
        return { icon: "✓", color: "text-success" };
      case "warning":
        return { icon: "⚠", color: "text-warning" };
      case "error":
        return { icon: "✗", color: "text-red-500" };
      default:
        return { icon: "•", color: "text-gray-500" };
    }
  };

  return (
    <section className="mb-8">
      <Card className="border border-gray-100">
        <CardHeader className="border-b border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg font-semibold text-secondary flex items-center">
                <i className="fas fa-robot mr-2 text-primary"></i>
                AI Data Collection Status
              </CardTitle>
              <p className="text-sm text-gray-600 mt-1">
                Automated lead collection across India updated daily
              </p>
            </div>
            <div className="text-right">
              <Badge className="bg-success/10 text-success border-success/20">
                <i className="fas fa-check-circle mr-1"></i>
                Active
              </Badge>
              <p className="text-xs text-gray-500 mt-1">Last run: {lastUpdate}</p>
            </div>
          </div>
        </CardHeader>

        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div className="bg-gradient-to-r from-blue-50 to-blue-100 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-blue-800">Sources Monitored</p>
                  <p className="text-2xl font-bold text-blue-900">156</p>
                </div>
                <i className="fas fa-globe text-blue-600 text-2xl"></i>
              </div>
              <p className="text-xs text-blue-700 mt-2">
                Real estate portals, social media, classified ads
              </p>
            </div>

            <div className="bg-gradient-to-r from-green-50 to-green-100 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-green-800">Today's Collection</p>
                  <p className="text-2xl font-bold text-green-900">247</p>
                </div>
                <i className="fas fa-download text-green-600 text-2xl"></i>
              </div>
              <p className="text-xs text-green-700 mt-2">
                New leads identified and processed
              </p>
            </div>

            <div className="bg-gradient-to-r from-orange-50 to-orange-100 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-orange-800">Accuracy Rate</p>
                  <p className="text-2xl font-bold text-orange-900">94.2%</p>
                </div>
                <i className="fas fa-chart-line text-orange-600 text-2xl"></i>
              </div>
              <p className="text-xs text-orange-700 mt-2">
                Contact validation and verification
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <h4 className="text-sm font-semibold text-gray-700 mb-3">Recent Processing Log</h4>
              <div className="bg-gray-50 rounded-lg p-4 space-y-2 max-h-48 overflow-y-auto">
                {processLogs.map((log, index) => {
                  const statusConfig = getStatusIcon(log.status);
                  return (
                    <div key={index} className="flex items-center space-x-3 text-sm">
                      <span className="text-gray-500 min-w-[60px]">{log.time}</span>
                      <span className={`${statusConfig.color} min-w-[20px]`}>
                        {statusConfig.icon}
                      </span>
                      <span className="text-gray-700">{log.message}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            <div>
              <h4 className="text-sm font-semibold text-gray-700 mb-3">Collection Settings</h4>
              <div className="space-y-3">
                <div className="flex items-center justify-between py-2 border-b border-gray-100">
                  <span className="text-sm text-gray-700">Auto-refresh frequency</span>
                  <span className="text-sm font-medium text-primary">Every 30 minutes</span>
                </div>
                <div className="flex items-center justify-between py-2 border-b border-gray-100">
                  <span className="text-sm text-gray-700">Contact verification</span>
                  <span className="text-sm font-medium text-success">
                    <i className="fas fa-toggle-on mr-1"></i> Enabled
                  </span>
                </div>
                <div className="flex items-center justify-between py-2 border-b border-gray-100">
                  <span className="text-sm text-gray-700">Duplicate detection</span>
                  <span className="text-sm font-medium text-success">
                    <i className="fas fa-toggle-on mr-1"></i> Enabled
                  </span>
                </div>
                <div className="flex items-center justify-between py-2">
                  <span className="text-sm text-gray-700">Geographic coverage</span>
                  <span className="text-sm font-medium text-primary">All India</span>
                </div>
              </div>
              <Button className="mt-4 w-full bg-primary hover:bg-blue-700 text-white">
                Configure AI Settings
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </section>
  );
}
