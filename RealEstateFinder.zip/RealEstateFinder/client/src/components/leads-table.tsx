import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useQuery } from "@tanstack/react-query";
import type { Lead, SearchLeadsParams } from "@shared/schema";

interface LeadsTableProps {
  searchParams: Partial<SearchLeadsParams>;
  onPageChange: (page: number) => void;
}

interface LeadsResponse {
  leads: Lead[];
  total: number;
}

export function LeadsTable({ searchParams, onPageChange }: LeadsTableProps) {
  const queryParams = new URLSearchParams();
  Object.entries(searchParams).forEach(([key, value]) => {
    if (value !== undefined) queryParams.append(key, value.toString());
  });

  const { data, isLoading, error } = useQuery<LeadsResponse>({
    queryKey: ["/api/leads", searchParams],
    queryFn: async () => {
      const response = await fetch(`/api/leads?${queryParams.toString()}`);
      if (!response.ok) throw new Error('Failed to fetch leads');
      return response.json();
    },
    refetchInterval: 30000,
  });

  const getRequirementBadge = (type: string) => {
    const typeMap: Record<string, { label: string; color: string; icon: string }> = {
      flat: { label: "Flat/Apartment", color: "bg-blue-100 text-blue-800", icon: "fas fa-building" },
      plot: { label: "Residential Plot", color: "bg-orange-100 text-orange-800", icon: "fas fa-map" },
      home_loan: { label: "Home Loan", color: "bg-green-100 text-green-800", icon: "fas fa-credit-card" },
      business_loan: { label: "Business Loan", color: "bg-purple-100 text-purple-800", icon: "fas fa-briefcase" },
      personal_loan: { label: "Personal Loan", color: "bg-red-100 text-red-800", icon: "fas fa-user" },
    };
    const config = typeMap[type] || { label: type, color: "bg-gray-100 text-gray-800", icon: "fas fa-question" };
    return config;
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(word => word[0]).join('').toUpperCase().slice(0, 2);
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return { date: "", time: "" };
    const date = new Date(dateString);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    let dateLabel = "";
    if (date.toDateString() === today.toDateString()) {
      dateLabel = "Today";
    } else if (date.toDateString() === yesterday.toDateString()) {
      dateLabel = "Yesterday";
    } else {
      dateLabel = date.toLocaleDateString();
    }

    const timeLabel = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    return { date: dateLabel, time: timeLabel };
  };

  if (isLoading) {
    return (
      <section className="mb-8">
        <Card className="border border-gray-100">
          <CardContent className="p-6">
            <div className="animate-pulse space-y-4">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="h-16 bg-gray-200 rounded"></div>
              ))}
            </div>
          </CardContent>
        </Card>
      </section>
    );
  }

  if (error) {
    return (
      <section className="mb-8">
        <Card className="border border-gray-100">
          <CardContent className="p-6 text-center text-red-500">
            Failed to load leads. Please try again.
          </CardContent>
        </Card>
      </section>
    );
  }

  if (!data) {
    return (
      <section className="mb-8">
        <Card className="border border-gray-100">
          <CardContent className="p-6 text-center text-gray-500">
            No leads data available.
          </CardContent>
        </Card>
      </section>
    );
  }

  const { leads, total } = data;
  const currentPage = searchParams.page || 1;
  const limit = searchParams.limit || 10;
  const totalPages = Math.ceil(total / limit);

  return (
    <section className="mb-8">
      <Card className="border border-gray-100">
        <CardHeader className="border-b border-gray-100">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
            <div>
              <h2 className="text-lg font-semibold text-secondary">Recent Leads</h2>
              <p className="text-sm text-gray-600 mt-1">
                Showing {leads.length} leads from {total} total results
              </p>
            </div>
            <div className="flex items-center space-x-2 mt-4 sm:mt-0">
              <span className="text-sm text-gray-600">Live updates</span>
              <span className="text-sm font-medium text-success">Active</span>
              <i className="fas fa-sync-alt text-success animate-pulse"></i>
            </div>
          </div>
        </CardHeader>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Contact Info
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Requirement
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Location
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Budget
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Added
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {leads.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-8 text-center text-gray-500">
                    No leads found matching your search criteria.
                  </td>
                </tr>
              ) : (
                leads.map((lead) => {
                  const requirement = getRequirementBadge(lead.requirementType);
                  const dateInfo = formatDate(lead.createdAt?.toString() || null);
                  
                  return (
                    <tr key={lead.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center space-x-3">
                          <Avatar className="h-10 w-10">
                            <AvatarFallback className="bg-primary text-white text-sm">
                              {getInitials(lead.name)}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="text-sm font-medium text-gray-900">{lead.name}</div>
                            <div className="text-sm text-gray-500">{lead.phone}</div>
                            {lead.email && (
                              <div className="text-sm text-gray-500">{lead.email}</div>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <Badge className={`${requirement.color} inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium`}>
                          <i className={`${requirement.icon} mr-1`}></i>
                          {requirement.label}
                        </Badge>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{lead.location}</div>
                        <div className="text-sm text-gray-500">{lead.area}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">
                          {lead.budget || "Not specified"}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{dateInfo.date}</div>
                        <div className="text-sm text-gray-500">{dateInfo.time}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <div className="flex items-center space-x-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-primary hover:text-blue-900"
                            title="Call"
                            onClick={() => window.open(`tel:${lead.phone}`, '_self')}
                          >
                            <i className="fas fa-phone"></i>
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-success hover:text-green-900"
                            title="WhatsApp"
                            onClick={() => window.open(`https://wa.me/${lead.phone.replace(/\D/g, '')}`, '_blank')}
                          >
                            <i className="fab fa-whatsapp"></i>
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-gray-400 hover:text-gray-600"
                            title="More"
                          >
                            <i className="fas fa-ellipsis-v"></i>
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="bg-white px-6 py-4 border-t border-gray-100">
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-500">
                Showing <span className="font-medium">{((currentPage - 1) * limit) + 1}</span> to{" "}
                <span className="font-medium">{Math.min(currentPage * limit, total)}</span> of{" "}
                <span className="font-medium">{total}</span> results
              </div>
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  disabled={currentPage <= 1}
                  onClick={() => onPageChange(currentPage - 1)}
                >
                  Previous
                </Button>
                {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                  const page = i + 1;
                  return (
                    <Button
                      key={page}
                      variant={currentPage === page ? "default" : "outline"}
                      size="sm"
                      onClick={() => onPageChange(page)}
                      className={currentPage === page ? "bg-primary text-white" : ""}
                    >
                      {page}
                    </Button>
                  );
                })}
                {totalPages > 5 && (
                  <>
                    <span className="text-sm text-gray-500">...</span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onPageChange(totalPages)}
                    >
                      {totalPages}
                    </Button>
                  </>
                )}
                <Button
                  variant="outline"
                  size="sm"
                  disabled={currentPage >= totalPages}
                  onClick={() => onPageChange(currentPage + 1)}
                >
                  Next
                </Button>
              </div>
            </div>
          </div>
        )}
      </Card>
    </section>
  );
}
