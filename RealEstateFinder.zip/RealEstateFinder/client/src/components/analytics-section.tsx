import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";

interface LocationStat {
  location: string;
  count: number;
}

interface TypeStat {
  type: string;
  count: number;
}

export function AnalyticsSection() {
  const { data: locationStats, isLoading: loadingLocations } = useQuery<LocationStat[]>({
    queryKey: ["/api/stats/locations"],
    refetchInterval: 60000,
  });

  const { data: typeStats, isLoading: loadingTypes } = useQuery<TypeStat[]>({
    queryKey: ["/api/stats/types"],
    refetchInterval: 60000,
  });

  const getProgressWidth = (count: number, maxCount: number) => {
    return Math.round((count / maxCount) * 100);
  };

  const getLocationColor = (index: number) => {
    const colors = ["bg-primary", "bg-accent", "bg-success", "bg-warning", "bg-purple-500"];
    return colors[index % colors.length];
  };

  const getTypeIcon = (type: string) => {
    const iconMap: Record<string, string> = {
      "Flat/Apartment": "fas fa-building",
      "Home Loan": "fas fa-credit-card",
      "Residential Plot": "fas fa-map",
      "Business Loan": "fas fa-briefcase",
      "Personal Loan": "fas fa-user",
    };
    return iconMap[type] || "fas fa-question";
  };

  const getTypeColor = (type: string) => {
    const colorMap: Record<string, string> = {
      "Flat/Apartment": "text-blue-500",
      "Home Loan": "text-green-500",
      "Residential Plot": "text-orange-500",
      "Business Loan": "text-purple-500",
      "Personal Loan": "text-red-500",
    };
    return colorMap[type] || "text-gray-500";
  };

  return (
    <section className="mb-8">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Location Analytics */}
        <Card className="border border-gray-100">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-secondary flex items-center">
              <i className="fas fa-chart-bar mr-2 text-primary"></i>
              Top Locations by Leads
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loadingLocations ? (
              <div className="space-y-4">
                {[1, 2, 3, 4, 5].map((i) => (
                  <div key={i} className="animate-pulse">
                    <div className="h-4 bg-gray-200 rounded mb-2"></div>
                    <div className="h-2 bg-gray-200 rounded"></div>
                  </div>
                ))}
              </div>
            ) : !locationStats || locationStats.length === 0 ? (
              <div className="text-center text-gray-500 py-8">
                No location data available
              </div>
            ) : (
              <div className="space-y-4">
                {locationStats.map((stat, index) => {
                  const maxCount = locationStats[0]?.count || 1;
                  const width = getProgressWidth(stat.count, maxCount);
                  const color = getLocationColor(index);
                  
                  return (
                    <div key={stat.location} className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className={`w-3 h-3 ${color} rounded-full`}></div>
                        <span className="text-sm font-medium">{stat.location}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className="w-24 bg-gray-200 rounded-full h-2">
                          <div 
                            className={`${color} h-2 rounded-full transition-all duration-500`}
                            style={{ width: `${width}%` }}
                          ></div>
                        </div>
                        <span className="text-sm text-gray-600">{stat.count} leads</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Requirement Type Analytics */}
        <Card className="border border-gray-100">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-secondary flex items-center">
              <i className="fas fa-pie-chart mr-2 text-primary"></i>
              Lead Distribution by Type
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loadingTypes ? (
              <div className="space-y-4">
                {[1, 2, 3, 4, 5].map((i) => (
                  <div key={i} className="animate-pulse">
                    <div className="h-8 bg-gray-200 rounded"></div>
                  </div>
                ))}
              </div>
            ) : !typeStats || typeStats.length === 0 ? (
              <div className="text-center text-gray-500 py-8">
                No type distribution data available
              </div>
            ) : (
              <div className="space-y-4">
                {typeStats.map((stat) => {
                  const totalLeads = typeStats.reduce((sum, s) => sum + s.count, 0);
                  const percentage = Math.round((stat.count / totalLeads) * 100);
                  const icon = getTypeIcon(stat.type);
                  const color = getTypeColor(stat.type);
                  
                  return (
                    <div key={stat.type} className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <i className={`${icon} ${color}`}></i>
                        <span className="text-sm font-medium">{stat.type}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="text-lg font-bold text-secondary">{stat.count}</span>
                        <span className="text-sm text-gray-500">({percentage}%)</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
