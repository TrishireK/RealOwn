import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const leads = pgTable("leads", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
  email: text("email"),
  requirementType: text("requirement_type").notNull(), // "flat", "plot", "home_loan", "business_loan", "personal_loan"
  location: text("location").notNull(),
  area: text("area").notNull(), // state/region
  budget: text("budget"),
  budgetMin: integer("budget_min"),
  budgetMax: integer("budget_max"),
  details: text("details"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertLeadSchema = createInsertSchema(leads).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const searchLeadsSchema = z.object({
  location: z.string().optional(),
  requirementType: z.string().optional(),
  budgetRange: z.string().optional(),
  dateRange: z.string().optional(),
  search: z.string().optional(),
  page: z.number().default(1),
  limit: z.number().default(10),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Lead = typeof leads.$inferSelect;
export type InsertLead = z.infer<typeof insertLeadSchema>;
export type SearchLeadsParams = z.infer<typeof searchLeadsSchema>;
